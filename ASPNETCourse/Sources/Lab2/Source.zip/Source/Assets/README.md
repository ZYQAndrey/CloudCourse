﻿To run this solution you need to configure the **CustomerContext** connection string as explained in Exercise 2 - Task 2. Notice that when compiling the solution, the NuGet packages dependencies will be automatically downloaded and installed.

